/*
 * GccApplication1.c
 *
 * Created: 3/28/2023 12:56:55 PM
 * Author : Networklab01
 */ 

//#include <avr/io.h>
//#define F_CPU 16000000UL
//#include <util/delay.h>
//
//void PIN_SETUP()
//{
    ///* Replace with your application code */
    //DDRB |= (1<<0);
	//PORTB &= ~(1<<0);
//}
//
//int main(void)
//{
	//PIN_SETUP();
	//while(1){
		//PORTB |= (1<<0);
		//_delay_ms(1000);
		//PORTB &= ~(1<<0);
		//_delay_ms(1000);
	//}
	//return (0);
//}


//#include <avr/io.h>
//
//void PIN_SETUP()
//{
 //DDRB |= (1<<0);
 //PORTB &= ~(1<<0);
 //DDRD &= ~(1<<4);
 //PORTD |= (1<<4);
//}
//
//int main(void)
//{
	//PIN_SETUP();
	//while(1){
		//if( ~PIND & (1<<4)){
			//PORTB |= (1<<0);
		//} else {
			//PORTB &= ~(1<<0);
		//}
	//}
	//return (0);
//}

//#include <avr/io.h>
//#include <avr/interrupt.h>
//
//unsigned char z =200;
//
//void PIN_SETUP()
//{
	//DDRB |= (1<<0);
	//PORTB &= ~(1<<0);
	//DDRB |= (1<<1);
	//PORTB &= ~(1<<1);
	//DDRD &= ~(1<<4);
	//PORTD |= (1<<4);
//}
//
//void TIMER0_SETUP() {
	//TCNT0 = 0xB2;
	//TCCR0A = 0x00;
	//TCCR0B = 0x05;
//}
//
//int main(void)
//{
	//PIN_SETUP();
	//TIMER0_SETUP();
	//TIMSK0 = (1<<TOIE0);
	//sei();
	//while(1){
		//if( ~PIND & (1<<4)){
			//PORTB |= (1<<0);
		//} else {
			//PORTB &= ~(1<<0);
		//}
	//}
	//return (0);
//}
//
//ISR (TIMER0_OVF_vect) {
	//z--;
	//if (z==0) {
		//z=200;
		//PORTB ^= (1<<1);
	//}
	//TCNT0=0xB2;
//}

//#include <avr/io.h>
//#include <avr/interrupt.h>
//
//void PIN_SETUP()
//{
	//DDRB |= (1<<0);
	//PORTB &= ~(1<<0);
	//DDRB |= (1<<1);
	//PORTB &= ~(1<<1);
	//DDRD &= ~(1<<4);
	//PORTD |= (1<<4);
	//PORTD |= (1<<2);
//}
//
//
//int main()
//{
	//PIN_SETUP();
	//EIMSK = 0x01;
	//EICRA = 0x02;
	//sei();
	//while(1){
		//if( ~PIND & (1<<4)){
			//PORTB |= (1<<0);
			//} else {
			//PORTB &= ~(1<<0);
		//}
	//}
	//return (0);
//}
//
//ISR (INT0_vect) {
	//PORTB ^= (1<<1);
//}

//#include <avr/io.h>
//#include <avr/interrupt.h>
//
//unsigned char z = 2;
//
//void PIN_SETUP()
//{
	//DDRB |= (1<<0);
	//PORTB &= ~(1<<0);
	//DDRB |= (1<<1);
	//PORTB &= ~(1<<1);
	//DDRD &= ~(1<<4);
	//PORTD |= (1<<4);
	//PORTC |= (1<<0);
//}
//
//
//int main()
//{
	//PIN_SETUP();
	//PCICR = 0x02;
	//PCMSK1 = 0x01;
	//sei();
	//while(1){
		//if( ~PIND & (1<<4)){
			//PORTB |= (1<<0);
			//} else {
			//PORTB &= ~(1<<0);
		//}
	//}
	//return (0);
//}
//
//ISR (PCINT1_vect) {
	//z--;
	//if (z==0){
		//PORTB ^= (1<<1);
		//z=2;
	//}
//}

//#include <avr/io.h>
//#include <avr/interrupt.h>
//
//unsigned char y =200;
//unsigned char z =2;
//
//void PIN_SETUP()
//{
	//DDRB |= 0b00001111;
	//PORTB &= ~0b00001111;
	//DDRD &= ~(1<<4);
	//PORTD |= (1<<4);
	//PORTD |= (1<<2);
	//PORTD |= (1<<5);
//}
//
//void TIMER0_SETUP(){
	//TCNT0 = 0xB2;
	//TCCR0A = 0x00;
	//TCCR0B = 0x05;
//}
//
//int main()
//{
	//PIN_SETUP();
	//TIMER0_SETUP();
	//
	//EIMSK = 0x02;
	//EICRA = 0x08;
	//
	//PCICR = 0x04;
	//PCMSK2 = 0x20;
	//
	//TIMSK0 = 0x01;
	//sei();
	//while(1){
		//if( ~PIND & (1<<4)){
			//PORTB |= (1<<0);
			//} else {
			//PORTB &= ~(1<<0);
		//}
	//}
	//return (0);
//}
//
//ISR (INT1_vect){
	//PORTB ^= (1<<1);
//}
//
//ISR (PCINT2_vect){
	//z--;
	//if (z==0) {
		//PORTB ^= (1<<2);
		//z=2;
	//}
//}
//
//ISR (TIMER0_OVF_vect){
	//y--;
	//if (y==0) {
		//y=200;
		//PORTB ^= (1<<3);
	//}
	//TCNT0 = 0xB2;
//}